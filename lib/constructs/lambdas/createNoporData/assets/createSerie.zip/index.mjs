import AWS from 'aws-sdk';
import { v4 as uuidv4 } from 'uuid';  // To generate unique IDs for the series
import * as multipart from 'parse-multipart-data'; // To parse the multipart form data

const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

const BUCKET_NAME = process.env.BUCKET_NAME || 'nopor-bucket-0-dev';
const TABLE_NAME = process.env.TABLE_NAME || 'SerieDatabase-dev';

export const handler = async (event) => {
  try {
    const boundary = multipart.getBoundary(event.headers['content-type']);
    const parts = multipart.parse(Buffer.from(event.body, 'base64'), boundary);

    // Find the file part
    const filePart = parts.find(part => part.filename);
    if (!filePart) {
      throw new Error('No file found in the form data');
    }
    const fileBuffer = filePart.data;

    // Generate unique ID for the series
    const serieId = uuidv4();

    // Upload thumbnail to S3
    await s3.putObject({
      Bucket: BUCKET_NAME,
      Key: `series-thumbnails/${serieId}.jpg`,  // Save with a unique name
      Body: fileBuffer,
      ContentType: filePart.contentType,
    }).promise();

    // Get URL for the uploaded thumbnail
    const thumbnailUrl = `https://${BUCKET_NAME}.s3.amazonaws.com/series-thumbnails/${serieId}.jpg`;

    // Now, collect the series data from other parts of the form
    const titlePart = parts.find(part => part.name === 'title');
    const releaseDatePart = parts.find(part => part.name === 'releaseDate');
    const descriptionPart = parts.find(part => part.name === 'description');
    const totalEpisodesPart = parts.find(part => part.name === 'totalEpisodes');
    const tagsPart = parts.find(part => part.name === 'tags');

    // Check if required fields are present
    if (!titlePart || !releaseDatePart || !descriptionPart || !totalEpisodesPart || !tagsPart) {
      throw new Error('Missing required form fields');
    }

    const title = titlePart.data.toString();
    const releaseDate = releaseDatePart.data.toString();
    const description = descriptionPart.data.toString();
    const totalEpisodes = Number(totalEpisodesPart.data.toString());
    const tags = tagsPart.data.toString();

    // Save the series data to DynamoDB
    const seriesData = {
      serieId,
      title,
      releaseDate,
      thumbnailUrl,
      description,
      totalEpisodes,
      lastModified: new Date().toISOString(),
      tags,
    };

    await dynamodb.put({
      TableName: TABLE_NAME,
      Item: seriesData
    }).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Series created successfully', serieId }),
    };

  } catch (error) {
    console.error('Error processing upload:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Failed to upload series', error: error.message }),
    };
  }
};
